import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Container, Row, Col, Form, Button } from 'react-bootstrap';
import { useDispatch } from 'react-redux';
import { signUpUser } from '../redux/authSlice';

const Register = () => {

    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const dispatch = useDispatch();

    const handleRegister = (e) => {
        e.preventDefault();
        dispatch(signUpUser({ name, email, password }));

    }

    return (
        <Container>
            <Row className="justify-content-md-center mt-5">
                <Col xs={12} md={6}>
                    <div>
                        <h2 className="text-center">Register</h2>
                        <Form onSubmit={handleRegister}>
                            <Form.Group className="mb-3">
                                <Form.Control type="text" placeholder="Name" name="name" value={name} onChange={(e) => setName(e.target.value)} />
                            </Form.Group>
                            <Form.Group className="mb-3">
                                <Form.Control type="text" placeholder="Email" name="email" value={email} onChange={(e) => setEmail(e.target.value)} />
                            </Form.Group>
                            <Form.Group className="mb-3">
                                <Form.Control type="password" placeholder="Password" name="password" value={password} onChange={(e) => setPassword(e.target.value)} />
                            </Form.Group>
                            <Button type="submit" variant="primary" className="w-100">Register</Button>
                        </Form>
                    </div>
                    <div>
                        <nav><p className='mt-3 '>Already have an account <Link to="/login">Login</Link></p></nav>
                    </div>
                </Col>
            </Row>
        </Container>
    );
};

export default Register;
