import React, { useState } from 'react';
import { Container, Row, Col, Form, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { signInUser } from '../redux/authSlice';
import { useDispatch } from 'react-redux';


const Login = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const dispatch = useDispatch();

    const handleLogin = (e)=>{
        e.preventDefault();
        dispatch(signInUser({email,password}));
    }

    return (
        <Container>
            <Row className="justify-content-md-center mt-5">
                <Col xs={12} md={6}>
                    <div>
                        <h2 className="text-center">Login</h2>
                        <Form onSubmit={handleLogin} >
                            <Form.Group className="mb-3">
                                <Form.Control type="email" placeholder="Email" name="email" value={email} onChange={(e) => setEmail(e.target.value)} />
                            </Form.Group>
                            <Form.Group className="mb-3">
                                <Form.Control type="password" placeholder="Password" name="password" value={password} onChange={(e) => setPassword(e.target.value)} />
                            </Form.Group>
                            <Button type="submit" variant="primary" className="w-100">Log In</Button>
                        </Form>
                    </div>
                    <div>
                        <nav><p className='mt-3 '>Don't have an account <Link to="/register">Register</Link></p></nav>
                    </div>
                </Col>
            </Row>
        </Container>
    );
};

export default Login;
